// console.log("async js")

console.log("Script start");

setInterval(() => {
    console.log("inside settime out ")
}, 1000)



console.log("code that take 1 hour")
console.log("script end");