import React from "react";
// import Counter from "./components/Counter";
import ManageStateInArray from "./ManageStateInArray";
function App() {
    return (
        <div>
            <ManageStateInArray />
        </div>
    );
}

export default App;
