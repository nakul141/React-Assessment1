import React from "react";

function Greeting({ firstName }) {
    return <h1>hello, {firstName}</h1>;
}

export default Greeting;
