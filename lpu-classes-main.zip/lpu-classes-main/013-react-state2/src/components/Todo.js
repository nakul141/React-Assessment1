import React from "react";

function Todo({ todo }) {
    return <h2>{todo}</h2>;
}

export default Todo;
