function Hello() {
    return <h1>Hello</h1>;
}

export default Hello;
