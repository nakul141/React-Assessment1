import React from "react";

function Sidebar() {
    return <div>Sidebar</div>;
}

export default Sidebar;
