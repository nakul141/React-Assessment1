// const numbers = [1, 2, 3, 4];

// const square = numbers.map((num) => {
//     return num ** 2;
// });

// const todos = ["teach students ", "edit videos ", "learn react "];

// const liTodos = todos.map((todo) => {
//     return `<li> ${todo} </li>`;
// });

// console.log(liTodos);

// rest operators

// array desctructuring
// const todos = ["play guitar", "learn music", "edit videos", "play cricket"];

// const [todo1, todo2, ...restTodos] = todos;

// const myobj = {
//     key1: "value1",
//     key2: "value2",
//     key3: "value3",
//     key4: "value4",
//     key5: "value5",
// };

// const { key1, key2, ...restKeys } = myobj;
// console.log(restKeys);

// function myfunc(input1, input2, ...restParams) {
//     // console.log(input1);
//     // console.log(input2);
//     console.log(restParams);
// }

// myfunc([1, 2, 3], 23, "abc", "xyz", "234");
