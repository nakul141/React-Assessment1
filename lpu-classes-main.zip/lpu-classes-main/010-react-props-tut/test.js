// function greeting(props) {
//     console.log(`hello, ${props.firstName} ${props.lastName} how are you ? `);
// }
// greeting({ firstName: "Harshit", lastName: "Vashisth" });
// greeting({ firstName: "Mohit", lastName: "Vashisth" });
// greeting({ firstName: "Nitish", lastName: "Vashisth" });
// greeting({ firstName: "Aditya", lastName: "Vashisth" });

// ternary operator
const isError = true;

const className = isError ? "there is an error" : "no Errors!!";
console.log(className);
